const Discord = require('discord.js');
const { inspect } = require('util')

module.exports.run = (bot, message, args) => {
        if(message.author.id !== 'seuid') return message.channel.send("Você não tem permissão para utilizar esse comando!");
        const input = args.join(" ");
        try {
            let output = eval(input);

            if(typeof output !== "string") output = inspect(output);

            if(output.size > 1950) output = output.substr(0, 1950);

            message.channel.send(`**Saida:**\n\`\`\`js\n${output}\n\`\`\``)
        } catch (error) {
          return message.channel.send(`**Error:**\n\`${error}\``);
        }
        
 }
