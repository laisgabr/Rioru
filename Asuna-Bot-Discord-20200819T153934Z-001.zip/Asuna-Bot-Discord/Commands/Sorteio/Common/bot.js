module.exports = {
    embeds: {
        color: "BLUE", 
        footers: "Feito por MrGamingBR#0001" 
    },

    events: {
        addcolor: "GREEN",
        remcolor: "RED"
    },

    reaction: "🎉"
};