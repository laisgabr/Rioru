# Asuna-Bot-Discord

Olá, Este é o Repositório da Yuuki Asuna :3

Gostaria de lhe alertar que se for feito um tipo de Plágio do Meu código sem minha Permissão, Automaticamente você será banido de usar a Yuuki Asuna. E ainda ficara sem o seu bot ,w, . Este bot foi feito com muito carinho por Mim(MrGamingBR), Caso use algum código daqui, Por favor coloque os Créditos já que não foi você que fez '-' . 

Não irei ajudar em relação dos Códigos.

